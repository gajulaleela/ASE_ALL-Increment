package mpg12.ase.umkc.createrecipe;

/**
 * Created by VINAYA on 3/26/2015.
 */
public class Person {
    private String recipename;
    private String ing1,ing2,ing3,ing4,ing5,ing6,ing7,ing8;
    private String q1,q2,q3,q4,q5,q6,q7,q8;
    private String u1,u2,u3,u4,u5,u6,u7,u8;

    public String getRecipename() {
        return recipename;
    }

    public void setRecipename(String recipename) {
        this.recipename = recipename;
    }
    public String getIng1() {
        return ing1;
    }

    public void setIng1(String ing1) {
        this.ing1 = ing1;
    }
    public String getIng2() {
        return ing2;
    }

    public void setIng2(String ing2) {
        this.ing2 = ing2;
    }
    public String getIng3() {
        return ing3;
    }

    public void setIng3(String ing3) {
        this.ing3 = ing3;
    }
    public String getIng4() {
        return ing4;
    }

    public void setIng4(String ing4) {
        this.ing4 = ing4;
    }
    public String getIng5() {
        return ing5;
    }

    public void setIng5(String ing5) {
        this.ing5 = ing5;
    }
    public String getIng6() {
        return ing6;
    }

    public void setIng6(String ing6) {
        this.ing6 = ing6;
    }
    public String getIng7() {
        return ing1;
    }

    public void setIng7(String ing7) {
        this.ing7 = ing7;
    }
    public String getIng8() {
        return ing8;
    }

    public void setIng8(String ing8) {
        this.ing8 = ing8;
    }
    public String getQ1() {
        return q1;
    }

    public void setQ1(String q1) {
        this.q1 = q1;
    }
    public String getQ2() {
        return q2;
    }

    public void setQ2(String q2) {
        this.q2 = q2;
    }
    public String getQ3() {
        return q1;
    }

    public void setQ3(String q3) {
        this.q3 = q3;
    }
    public String getQ4() {
        return q4;
    }

    public void setQ4(String q4) {
        this.q4 = q4;
    }
    public String getQ5() {
        return q5;
    }

    public void setQ5(String q5) {
        this.q5 = q5;
    }
    public String getQ6() {
        return q6;
    }

    public void setQ6(String q6) {
        this.q6 = q6;
    }
    public String getQ7() {
        return q7;
    }

    public void setQ7(String q7) {
        this.q7 = q7;
    }
    public String getQ8() {
        return q8;
    }

    public void setQ8(String q8) {
        this.q8 = q8;
    }
    public String getU1() {
        return u1;
    }

    public void setU1(String u1) {
        this.u1 = u1;
    }
    public String getU2() {
        return u2;
    }

    public void setU2(String u2) {
        this.u2 = u2;
    }
    public String getU3() {
        return u3;
    }

    public void setU3(String u3) {
        this.u3 = u3;
    }
    public String getU4() {
        return u4;
    }

    public void setU4(String u4) {
        this.u4 = u4;
    }
    public String getU5() {
        return u5;
    }

    public void setU5(String u5) {
        this.u5 = u5;
    }
    public String getU6() {
        return u6;
    }

    public void setU6(String u6) {
        this.u6 = u6;
    }
    public String getU7() {
        return u7;
    }

    public void setU7(String u7) {
        this.u7 = u7;
    }
    public String getU8() {
        return u8;
    }

    public void setU8(String u8) {
        this.u8 = u8;
    }


    @Override
    public String toString() {
        return "Person [recipename=" +recipename+ ",ing1="+ing1+",ing2="+ing2+",ing3="+ing3+",ing4="+ing4+",ing5="+ing5+",ing6="+ing6+",ing7="+ing7+",ing8="+ing8+", q1=" + q1 + ",q2="+q2+",q3="+q3+",q4="+q4+",q5="+q5+",q6="+q6+",q7="+q7+",q8="+q8+",u1="+u1+",u2="+u2+",u3="+u3+",u4="+u4+",u5="+u5+",u6="+u6+",u7="+u7+",u8="+u8+ "]";
    }


}
