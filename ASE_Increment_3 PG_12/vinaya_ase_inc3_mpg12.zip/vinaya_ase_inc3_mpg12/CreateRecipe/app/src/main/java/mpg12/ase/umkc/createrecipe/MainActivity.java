package mpg12.ase.umkc.createrecipe;

import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;


public class MainActivity extends ActionBarActivity implements View.OnClickListener {
    Button button;
    Person person;
    /*  AlertDialog.Builder alert;
  String newrecipe, newrecipe1;*/
    EditText recipename, ing1, q1, u1, ing2, q2, u2, ing3, q3, u3, ing4, q4, u4, ing5, q5, u5, ing6, q6, u6, ing7, q7, u7, ing8, q8, u8;
    String recipetitle, in1, qu1, un1, in2, qu2, un2, in3, qu3, un3, in4, qu4, un4, in5, qu5, un5, in6, qu6, un6, in7, qu7, un7, in8, qu8, un8;

    // public String url = "http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo/df/f/df/aef/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/awefaerg/efsef";
    // public final static String newurl = "http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo";
    //String newurl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recipename = (EditText) findViewById(R.id.recipename);
        ing1 = (EditText) findViewById(R.id.ing1);
        q1 = (EditText) findViewById(R.id.q1);
        u1 = (EditText) findViewById(R.id.u1);
        ing2 = (EditText) findViewById(R.id.ing2);
        q2 = (EditText) findViewById(R.id.q2);
        u2 = (EditText) findViewById(R.id.u2);
        ing3 = (EditText) findViewById(R.id.ing3);
        q3 = (EditText) findViewById(R.id.q3);
        u3 = (EditText) findViewById(R.id.u3);
        ing4 = (EditText) findViewById(R.id.ing4);
        q4 = (EditText) findViewById(R.id.q4);
        u4 = (EditText) findViewById(R.id.u4);
        ing5 = (EditText) findViewById(R.id.ing5);
        q5 = (EditText) findViewById(R.id.q5);
        u5 = (EditText) findViewById(R.id.u5);
        ing6 = (EditText) findViewById(R.id.ing6);
        q6 = (EditText) findViewById(R.id.q6);
        u6 = (EditText) findViewById(R.id.u6);
        ing7 = (EditText) findViewById(R.id.ing7);
        q7 = (EditText) findViewById(R.id.q7);
        u7 = (EditText) findViewById(R.id.u7);
        ing8 = (EditText) findViewById(R.id.ing8);
        q8 = (EditText) findViewById(R.id.q8);
        u8 = (EditText) findViewById(R.id.u8);
        /*recipetitle = recipename.getText().toString();
        in1 = ing1.getText().toString();
        qu1 = q1.getText().toString();
        un1 = u1.getText().toString();
        in2 = ing2.getText().toString();
        qu2 = q2.getText().toString();
        un2 = u2.getText().toString();
        in3 = ing3.getText().toString();
        qu3 = q3.getText().toString();
        un3 = u3.getText().toString();
        in4 = ing4.getText().toString();
        qu4 = q4.getText().toString();
        un4 = u4.getText().toString();
        in5 = ing5.getText().toString();
        qu5 = q5.getText().toString();
        un5 = u5.getText().toString();
        in6 = ing6.getText().toString();
        qu6 = q6.getText().toString();
        un6 = u6.getText().toString();
        in7 = ing7.getText().toString();
        qu7 = q7.getText().toString();
        un7 = u7.getText().toString();
        in8 = ing8.getText().toString();
        qu8 = q8.getText().toString();
        un8 = u8.getText().toString();*/
        button = (Button) findViewById(R.id.button);

        button.setOnClickListener(this);
    }

    public static String POST(String url, Person person) {
        InputStream inputStream = null;
        String result = "";
        try {

            // 1. create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // 2. make POST request to the given URL
            HttpPost httpPost = new HttpPost(url);

            String json = "";


            // 3. build jsonObject
            JSONObject jsonObject = new JSONObject();
            jsonObject.accumulate("recipename", person.getRecipename());
            jsonObject.accumulate("ing1", person.getIng1());
            jsonObject.accumulate("ing2", person.getIng2());
            jsonObject.accumulate("ing3", person.getIng3());
            jsonObject.accumulate("ing4", person.getIng4());
            jsonObject.accumulate("ing5", person.getIng5());
            jsonObject.accumulate("ing6", person.getIng6());
            jsonObject.accumulate("ing7", person.getIng7());
            jsonObject.accumulate("ing8", person.getIng8());
            jsonObject.accumulate("q1", person.getQ1());
            jsonObject.accumulate("q2", person.getQ2());
            jsonObject.accumulate("q3", person.getQ3());
            jsonObject.accumulate("q4", person.getQ4());
            jsonObject.accumulate("q5", person.getQ5());
            jsonObject.accumulate("q6", person.getQ6());
            jsonObject.accumulate("q7", person.getQ7());
            jsonObject.accumulate("q8", person.getQ8());
            jsonObject.accumulate("u1", person.getU1());
            jsonObject.accumulate("u2", person.getU2());
            jsonObject.accumulate("u3", person.getU3());
            jsonObject.accumulate("u4", person.getU4());
            jsonObject.accumulate("u5", person.getU5());
            jsonObject.accumulate("u6", person.getU6());
            jsonObject.accumulate("u7", person.getU7());
            jsonObject.accumulate("u8", person.getU8());


            // 4. convert JSONObject to JSON to String
            json = jsonObject.toString();


            // ** Alternative way to convert Person object to JSON string usin Jackson Lib
            // ObjectMapper mapper = new ObjectMapper();
            // json = mapper.writeValueAsString(person);

            // 5. set json to StringEntity
            StringEntity se = new StringEntity(json);

            // 6. set httpPost Entity
            httpPost.setEntity(se);

            // 7. Set some headers to inform server about the type of the content
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            // 8. Execute POST request to the given URL
            HttpResponse httpResponse = httpclient.execute(httpPost);

            // 9. receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();


            // 10. convert inputstream to string
            if (inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        // 11. return result
        return result;
    }

    @Override
    public void onClick(View view) {

       // switch (view.getId()) {
           // case R.id.button:
               // if (!validate())
                    //Toast.makeText(getBaseContext(), "Enter some data!", Toast.LENGTH_LONG).show();
                // call AsynTask to perform network operation on separate thread
                new HttpAsyncTask().execute("http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo");
               // break;
        }



    public boolean isConnected() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }

    private class HttpAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls) {

            person = new Person();
            person.setRecipename(recipename.getText().toString());
            person.setIng1(ing1.getText().toString());
            person.setIng2(ing2.getText().toString());
            person.setIng3(ing3.getText().toString());
            person.setIng4(ing4.getText().toString());
            person.setIng5(ing5.getText().toString());
            person.setIng6(ing6.getText().toString());
            person.setIng7(ing7.getText().toString());
            person.setIng8(ing8.getText().toString());
            person.setQ1(q1.getText().toString());
            person.setQ2(q2.getText().toString());
            person.setQ3(q3.getText().toString());
            person.setQ4(q4.getText().toString());
            person.setQ5(q5.getText().toString());
            person.setQ6(q6.getText().toString());
            person.setQ7(q7.getText().toString());
            person.setQ8(q8.getText().toString());
            person.setU1(u1.getText().toString());
            person.setU2(u2.getText().toString());
            person.setU3(u3.getText().toString());
            person.setU4(u4.getText().toString());
            person.setU5(u5.getText().toString());
            person.setU6(u6.getText().toString());
            person.setU7(u7.getText().toString());
            person.setU8(u8.getText().toString());

            return POST(urls[0], person);
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getBaseContext(), "Data Sent!", Toast.LENGTH_LONG).show();
        }
    }


    private boolean validate() {
        if (recipename.getText().toString().trim().equals(""))
            return false;
        else if (ing1.getText().toString().trim().equals(""))
            return false;
        else if (ing2.getText().toString().trim().equals(""))
            return false;
        else if (ing3.getText().toString().trim().equals(""))
            return false;
        else if (ing4.getText().toString().trim().equals(""))
            return false;
        else if (ing5.getText().toString().trim().equals(""))
            return false;
        else if (ing6.getText().toString().trim().equals(""))
            return false;
        else if (ing7.getText().toString().trim().equals(""))
            return false;
        else if (ing8.getText().toString().trim().equals(""))
            return false;
        else if (q1.getText().toString().trim().equals(""))
            return false;
        else if (q2.getText().toString().trim().equals(""))
            return false;
        else if (q3.getText().toString().trim().equals(""))
            return false;
        else if (q4.getText().toString().trim().equals(""))
            return false;
        else if (q5.getText().toString().trim().equals(""))
            return false;
        else if (q6.getText().toString().trim().equals(""))
            return false;
        else if (q7.getText().toString().trim().equals(""))
            return false;
        else if (q8.getText().toString().trim().equals(""))
            return false;
        else if (u1.getText().toString().trim().equals(""))
            return false;
        else if (u2.getText().toString().trim().equals(""))
            return false;
        else if (u3.getText().toString().trim().equals(""))
            return false;
        else if (u4.getText().toString().trim().equals(""))
            return false;
        else if (u5.getText().toString().trim().equals(""))
            return false;
        else if (u6.getText().toString().trim().equals(""))
            return false;
        else if (u7.getText().toString().trim().equals(""))
            return false;
        else if (u8.getText().toString().trim().equals(""))
            return false;

        else
            return true;
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }

       /*button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // new HttpAsyncTask().execute("http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo/df/f/df/aef/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/"+q8.getText().toString()+"/hjkf");

            }
        });
    }*/

//newrecipe = "http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo/df/f/df/aef/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/%20/asc";
//newrecipe1 = newrecipe.concat(un8);


  /*  public void showalert() {

        //newurl = "http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo/" + recipetitle + "/" + in1 + "/" + qu1 + "/" + un1 + "/" + in2 + "/" + qu2 + "/" + un2 + "/" + in3 + "/" + qu3 + "/" + un3 + "/" + in4 + "/" + qu4 + "/" + un4 + "/" + in5 + "/" + qu5 + "/" + un5 + "/" + in6 + "/" + qu6 + "/" + un6 + "/" + in7 + "/" + qu7 + "/" + un7 + "/" + in8 + "/" + qu8 + "/" + un8;

        alert = new AlertDialog.Builder(MainActivity.this)
                .setTitle("SHOW FIELDS")
                .setMessage("" + newrecipe + "" + recipetitle + "" + in1 + "" + qu1 + "" + un1 + "" + in2 + "" + qu2 + "" + un2 + "" + in3 + "" + qu3 + "" + un3 + "" + in4 + "" + qu4 + "" + un4 + "" + in5 + "" + qu5 + "" + un5 + "" + in6 + "" + qu6 + "" + un6 + "" + in7 + "" + qu7 + "" + un7 + "" + in8 + "" + qu8 + "" + un8)
                .setNegativeButton("CLOSE", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // do nothing
                        closeContextMenu();
                    }
                });
        alert.show();
    }

    public static String POST(String url) {
        InputStream inputStream = null;
        String result = "";

        try {

            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(url));
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("recipename", recipetitle);
            jsonObj.put("ing1", in1);
            jsonObj.put("u8", un8);
// Create the POST object and add the parameters


            // receive response as inputStream
           // inputStream = entity.getContent();
            // convert inputstream to string
            if (inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        return result;
    }


    private class HttpAsyncTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {

            return GET(urls[0]);

        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {

            Toast.makeText(getBaseContext(), "Received!" +un8, Toast.LENGTH_LONG).show();
            //etResponse.setText(result);
        }

        @Override
        protected void onPreExecute() {

            // newurl = "http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/vinaya2/Createrecipe/Service1.svc/insertinfo/" + recipetitle + "/" + in1 + "/" + qu1 + "/" + un1 + "/" + in2 + "/" + qu2 + "/" + un2 + "/" + in3 + "/" + qu3 + "/" + un3 + "/" + in4 + "/" + qu4 + "/" + un4 + "/" + in5 + "/" + qu5 + "/" + un5 + "/" + in6 + "/" + qu6 + "/" + un6 + "/" + in7 + "/" + qu7 + "/" + un7 + "/" + in8 + "/" + qu8 + "/" + un8;

        }
    }


    private static String convertInputStreamToString(InputStream inputStream) throws IOException {

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/



}