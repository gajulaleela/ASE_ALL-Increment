﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using System.Net;
using System.IO;

namespace Nunit_UpdateGrocery
{
    public class Service
    {
         [Test]
        public void UpdateGroceryTest()
        {
             WebRequest req = WebRequest.Create
  (@"http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/Sravani/viewGrocery/Service1.svc/updateGrocery/Sravani/honey/20/lb");

            req.Method = "GET";

            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;
            if (resp.StatusCode == HttpStatusCode.OK)
            {
                using (Stream respStream = resp.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(respStream, Encoding.UTF8);

            Assert.AreEqual 
                ("{\"measure\":\"lb\",\"name\":\"honey\",\"opt_msg\":\"Updated\",\"quantity\":\"20\",\"user\":\"Sravani\"}", reader.ReadToEnd().ToString());
                }
            }
            else
            {
                Console.WriteLine(string.Format("Status Code: {0}, Status Description: {1}", resp.StatusCode, resp.StatusDescription));
            }
            Console.Read();

        }


        [Test]
        public void DeleteGroceryTest()
        {
            //insert tom/25/umkc/student

            WebRequest req = WebRequest.Create
  (@"http://kc-sce-cs551-2.kc.umkc.edu/aspnet_client/MPG12/Sravani/viewGrocery/Service1.svc/deleteGrocery/Sravani/carrots");

            req.Method = "GET";

            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;
            if (resp.StatusCode == HttpStatusCode.OK)
            {
                using (Stream respStream = resp.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(respStream, Encoding.UTF8);

                    Assert.AreEqual
                        ("{\"measure\":null,\"name\":\"carrots\",\"opt_msg\":\"Deleted\",\"quantity\":null,\"user\":\"Sravani\"}", reader.ReadToEnd().ToString());
                }
            }
            else
            {
                Console.WriteLine(string.Format("Status Code: {0}, Status Description: {1}", resp.StatusCode, resp.StatusDescription));
            }
            Console.Read();

        }
    }


    }

