﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.Script.Serialization;
using System.Web.Script.Services;

namespace viewGrocery
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class Service1 : IService1
    {

        // This method is used to view the data in grocery_list table

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "updateGrocery/{uname}/{gname}/{gqty}/{g_unit}")]

        public GItem updateGrcry(string uname , string gname , String gqty , String g_unit)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

            conn.Open();

            SqlCommand cmd1 = new SqlCommand("update grocery_list set g_quantity ='" + gqty + "', g_measure ='" + g_unit + "' , g_update_dt = CONVERT(VARCHAR(10), GETDATE(), 20), g_expiry_dt = CONVERT(varchar(10), GETDATE() + 5, 20) where g_name ='" + gname + "' and user_id = (select user_id from user_profile where user_name ='" + uname + "' )", conn);

            cmd1.ExecuteNonQuery();
            conn.Close();

            return new GItem()
            {
                user = uname,
                name = gname,
                quantity = gqty,
                measure = g_unit,
                opt_msg = "Updated"
            };

          
        }

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "deleteGrocery/{uname}/{gname}")]

        public GItem deleteGrcry(string uname, string gname)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

            conn.Open();

            SqlCommand cmd1 = new SqlCommand("delete from grocery_list where g_name='" + gname + "' and user_id = (select user_id from user_profile where user_name ='" + uname + "' )", conn);

            cmd1.ExecuteNonQuery();
            conn.Close();

            return new GItem()
            {
                user = uname,
                name = gname,
                opt_msg = "Deleted"
            };


        }


        // This method is used to retrieve grocery_list in json format

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "JsonGrocery/{uname}")]

        public String JsonvwGrocery(string uname)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

            conn.Open();

            SqlCommand cmd1 = new SqlCommand("select g_name , g_quantity , g_measure, CONVERT(varchar(10) , g_expiry_dt) from grocery_list a inner join user_profile b on (a.user_id = b.user_id) where b.user_name='" + uname + "'", conn);
            DataTable dt = new DataTable();
            cmd1.ExecuteNonQuery();
            SqlDataAdapter objDataAdapter = new SqlDataAdapter(cmd1);
            objDataAdapter.Fill(dt);
            conn.Close();
            Console.WriteLine(dt);
         
     System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
            List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
            Dictionary<string, object> row;
            foreach (DataRow dr in dt.Rows)
            {
                row = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    row.Add(col.ColumnName, dr[col]);
                }
                rows.Add(row);
            }
            String sr= serializer.Serialize(rows);
            Console.WriteLine(sr);
            //String result = sr.Replace("\\", "");
            String result = sr;
            Console.WriteLine(result);
            return result;
        }
    
    




        /// <summary>
        ///  This method inserts data into grocery_list table
        /// </summary>
        /// <param name="uname"></param>
        /// <param name="gname"></param>
        /// <param name="gqty"></param>
        /// <param name="gmsure"></param>
        /// <returns></returns>

        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, UriTemplate = "addgrocery/{uname}/{gname}/{gqty}/{gmsure}")]

        public GItem Getgrcry(string uname, string gname, String gqty, string gmsure)
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["dbString"].ConnectionString);

            conn.Open();

            String o_msg = "3";
            String out_msg;

            SqlCommand cmd = new SqlCommand("Add_Grocery", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", uname);
            cmd.Parameters.AddWithValue("@name", gname);
            cmd.Parameters.AddWithValue("@quan", gqty);
            cmd.Parameters.AddWithValue("@msure", gmsure);
            cmd.Parameters.Add("@msg", SqlDbType.Int).Direction = ParameterDirection.Output;


            cmd.ExecuteNonQuery();

            o_msg = cmd.Parameters["@msg"].Value.ToString();

            conn.Close();

            switch (o_msg)
            {
                case "0":
                    out_msg = "Added the item";
                    break;
                case "1":
                    out_msg = "Invalid grocery item name";
                    break;
                case "2":
                    out_msg = "Grocery item with the same name already exists,please use update option";
                    break;
                default:
                    out_msg = "Unknown";
                    break;
            }

            return new GItem()
            {
                user = uname,
                name = gname,
                quantity = gqty,
                measure = gmsure,
                opt_msg = out_msg
            };
        }
        
  
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }



  

    
   
}
